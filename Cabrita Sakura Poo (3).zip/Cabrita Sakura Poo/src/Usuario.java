public class Usuario {

    private int idUsuario;
    private String nombre;
    private String apellido;
    private String correo;
    private String contrasena;
    private String direccion;
    private String telefono;
    private String estado;
    private String rol; // 🔹 nuevo campo

    // 🔹 Constructor completo con rol incluido
    public Usuario(int idUsuario, String nombre, String apellido, String correo, String contrasena,
                   String direccion, String telefono, String estado, String rol) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.contrasena = contrasena;
        this.direccion = direccion;
        this.telefono = telefono;
        this.estado = estado;
        this.rol = rol;
    }

    // 🔹 Getters
    public int getIdUsuario() { return idUsuario; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getCorreo() { return correo; }
    public String getContrasena() { return contrasena; }
    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public String getEstado() { return estado; }
    public String getRol() { return rol; } // 🔹 getter del rol

    // 🔹 Setters
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setRol(String rol) { this.rol = rol; } // 🔹 setter del rol

    @Override
    public String toString() {
        return nombre + " " + apellido + " (" + correo + ")";
    }
}
