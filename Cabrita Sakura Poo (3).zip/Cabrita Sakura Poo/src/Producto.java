public class Producto {
    private int idProducto;
    private String nombre;
    private String descripcion;
    private double precio;
    private Categoria categoria;
    private Fabricante fabricante;

    // 🔹 Constructor completo
    public Producto(int idProducto, String nombre, String descripcion, double precio,
                    Categoria categoria, Fabricante fabricante) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.categoria = categoria;
        this.fabricante = fabricante;
    }

    // 🔹 Constructor básico
    public Producto(int idProducto, String nombre, String descripcion, double precio) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.categoria = null; // o asignar una categoría por defecto
        this.fabricante = null; // o asignar un fabricante por defecto
    }

    // 🔹 Getters y Setters
    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Fabricante getFabricante() {
        return fabricante;
    }

    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante;
    }

    // 🔹 Sobrescritura de toString para mostrar correctamente la información
    @Override
    public String toString() {
        String categoriaTexto = (categoria != null) ? categoria.toString() : "Alimento";
        String fabricanteTexto = (fabricante != null) ? fabricante.toString() : "Proveedor Local";

        return "ID: " + idProducto +
                " | Nombre: " + nombre +
                " | Descripción: " + descripcion +
                " | Precio: $" + precio +
                " | Categoría: " + categoriaTexto +
                " | Fabricante: " + fabricanteTexto;
    }
}
