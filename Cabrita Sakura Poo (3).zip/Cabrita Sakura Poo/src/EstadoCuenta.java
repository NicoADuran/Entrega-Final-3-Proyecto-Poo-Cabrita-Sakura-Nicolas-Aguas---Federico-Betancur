public enum EstadoCuenta {
    ACTIVO,
    INACTIVO,
    SUSPENDIDO
}
