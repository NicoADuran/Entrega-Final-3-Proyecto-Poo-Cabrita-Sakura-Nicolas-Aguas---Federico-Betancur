public enum Rol {
    CLIENTE,
    DUENA,
    ADMIN

}
