public enum EstadoOrden {
    EN_PROCESO,
    ENVIADO,
    ENTREGADO,
    CANCELADO
}
