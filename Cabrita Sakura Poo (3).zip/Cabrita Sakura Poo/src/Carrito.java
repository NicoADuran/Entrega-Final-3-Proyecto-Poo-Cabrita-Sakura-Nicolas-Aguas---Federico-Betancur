import java.util.ArrayList;
import java.util.List;

public class Carrito {

    private List<LineaCompra> lineas;

    // 🔹 Constructor
    public Carrito() {
        this.lineas = new ArrayList<>();
    }

    // 🔹 Agregar un producto al carrito
    public void agregarProducto(Producto producto, int cantidad) {
        if (producto == null) {
            System.out.println("❌ Error: el producto no puede ser nulo.");
            return;
        }

        if (cantidad <= 0) {
            System.out.println("❌ Error: la cantidad debe ser mayor a cero.");
            return;
        }

        // Si el producto ya está en el carrito, aumentamos la cantidad
        for (LineaCompra linea : lineas) {
            if (linea.getProducto().equals(producto)) {
                linea.setCantidad(linea.getCantidad() + cantidad);
                System.out.println("🛒 Cantidad actualizada del producto: " + producto.getNombre());
                return;
            }
        }

        // Si no estaba, lo agregamos como nueva línea
        lineas.add(new LineaCompra(producto, cantidad));
        System.out.println("✅ Producto agregado al carrito: " + producto.getNombre());
    }

    // 🔹 Mostrar el contenido del carrito
    public void mostrarCarrito() {
        if (lineas.isEmpty()) {
            System.out.println("🛍️ El carrito está vacío.");
            return;
        }

        System.out.println("\n🛒 Carrito de compras:");
        for (LineaCompra linea : lineas) {
            System.out.println(linea);
        }
        System.out.println("💰 Total: $" + calcularTotal());
    }

    // 🔹 Calcular el total del carrito
    public double calcularTotal() {
        double total = 0;
        for (LineaCompra linea : lineas) {
            total += linea.getSubtotal();
        }
        return total;
    }

    // 🔹 Vaciar el carrito (importante para después de comprar)
    public void vaciarCarrito() {
        lineas.clear();
        System.out.println("🧹 Carrito vaciado correctamente.");
    }

    // 🔹 Obtener las líneas de compra (para crear una Compra)
    public List<LineaCompra> getLineas() {
        return lineas;
    }
}
