/**
 * Mensaje / consejo relacionado a un producto.
 */
public class ConsejoConsumo {
    private Producto producto;
    private String mensaje;

    public ConsejoConsumo(Producto producto, String mensaje) {
        this.producto = producto;
        this.mensaje = mensaje;
    }

    public Producto getProducto() {
        return producto;
    }

    public String getMensaje() {
        return mensaje;
    }

    @Override
    public String toString() {
        return "Consejo para " + (producto != null ? producto.getNombre() : "producto") + ": " + mensaje;
    }
}
