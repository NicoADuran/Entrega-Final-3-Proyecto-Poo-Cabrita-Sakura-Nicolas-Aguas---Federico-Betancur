import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        List<Usuario> usuarios = new ArrayList<>();
        List<Cliente> clientes = new ArrayList<>();
        List<Compra> compras = new ArrayList<>();
        List<Producto> productos = new ArrayList<>();

        RegistroUsuarios registro = new RegistroUsuarios(usuarios, 1, 1);

        // === CREAMOS LA DUEÑA ===
        Duena duena = new Duena(
                1, "Sakura", "Cabrita", "admin@tienda.com", "1234",
                "Calle Principal 1", "3001234567", "Activo", "Dueña"
        );
        usuarios.add(duena);

        // === CREAMOS UN CLIENTE DEMO ===
        Cliente clienteDemo = registro.registrarCliente(
                "Nico", "Vera", "nico@correo.com", "1234",
                "Calle Falsa 123", "3015559999", "Activo"
        );
        clientes.add(clienteDemo);
        usuarios.add(clienteDemo);

        // === LISTA DE PRODUCTOS BASE ===
        productos.add(new Producto(1, "Manzanas", "Frutas frescas", 3.0));
        productos.add(new Producto(2, "Leche", "Entera 1 litro", 2.5));
        productos.add(new Producto(3, "Pan", "Pan artesanal", 1.5));

        Usuario usuarioActivo = null;
        int opcion;

        do {
            System.out.println("\n===== MENÚ PRINCIPAL =====");
            System.out.println("1. Iniciar sesión");
            System.out.println("2. Registrar nuevo cliente");
            System.out.println("3. Ver productos disponibles");
            System.out.println("4. Realizar compra (solo clientes)");
            System.out.println("5. Registrar nuevo producto (solo admin)");
            System.out.println("6. Ver compras (solo admin)");
            System.out.println("7. Ver historial de compras (cliente)");
            System.out.println("8. Exportar información a TXT (solo admin)");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                // LOGIN
                case 1 -> {
                    System.out.print("Correo: ");
                    String correo = sc.nextLine();
                    System.out.print("Contraseña: ");
                    String contrasena = sc.nextLine();

                    usuarioActivo = registro.login(correo, contrasena);

                    if (usuarioActivo != null) {
                        System.out.println("✅ Bienvenido, " + usuarioActivo.getNombre() + " (" + usuarioActivo.getRol() + ")");
                    } else {
                        System.out.println("❌ Credenciales incorrectas.");
                    }
                }

                // REGISTRAR CLIENTE
                case 2 -> {
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Apellido: ");
                    String apellido = sc.nextLine();
                    System.out.print("Correo: ");
                    String correo = sc.nextLine();
                    System.out.print("Contraseña: ");
                    String contrasena = sc.nextLine();
                    System.out.print("Dirección: ");
                    String direccion = sc.nextLine();
                    System.out.print("Teléfono: ");
                    String telefono = sc.nextLine();

                    Cliente nuevo = registro.registrarCliente(
                            nombre, apellido, correo, contrasena,
                            direccion, telefono, "Activo"
                    );
                    clientes.add(nuevo);
                    usuarios.add(nuevo);
                    System.out.println("✅ Cliente registrado con éxito.");
                }

                // VER PRODUCTOS
                case 3 -> {
                    System.out.println("\n=== PRODUCTOS DISPONIBLES ===");
                    for (Producto p : productos) {
                        System.out.println(p.getIdProducto() + " - " + p.getNombre() + " | $" + p.getPrecio());
                    }
                }

                // COMPRAR PRODUCTO (MEJORADO)
                case 4 -> realizarCompra(sc, usuarioActivo, productos, compras, duena);

                // REGISTRAR PRODUCTO NUEVO (solo dueña)
                case 5 -> {
                    if (usuarioActivo == null || !(usuarioActivo instanceof Duena)) {
                        System.out.println("⚠️ Debe iniciar sesión como dueña para registrar productos.");
                        break;
                    }

                    System.out.print("Nombre del producto: ");
                    String nombre = sc.nextLine();
                    System.out.print("Descripción: ");
                    String desc = sc.nextLine();
                    System.out.print("Precio: ");
                    double precio = sc.nextDouble();
                    sc.nextLine();

                    Producto nuevo = new Producto(productos.size() + 1, nombre, desc, precio);
                    productos.add(nuevo);
                    System.out.println("✅ Producto agregado exitosamente.");
                }

                // VER COMPRAS (solo dueña)
                case 6 -> {
                    if (usuarioActivo == null || !(usuarioActivo instanceof Duena)) {
                        System.out.println("⚠️ Debe iniciar sesión como dueña para ver las compras.");
                        break;
                    }
                    duena.verCompras();
                }

                // VER HISTORIAL DE COMPRAS DEL CLIENTE
                case 7 -> {
                    if (usuarioActivo == null || !(usuarioActivo instanceof Cliente)) {
                        System.out.println("⚠️ Debe iniciar sesión como cliente para ver su historial.");
                        break;
                    }

                    Cliente clienteActivo = (Cliente) usuarioActivo;
                    System.out.println("\n=== HISTORIAL DE COMPRAS ===");
                    for (Compra compra : compras) {
                        if (compra.getCliente().equals(clienteActivo)) {
                            System.out.println(compra);
                        }
                    }
                }

                // EXPORTAR INFORMACIÓN A TXT (solo dueña)
                case 8 -> {
                    if (usuarioActivo == null || !(usuarioActivo instanceof Duena)) {
                        System.out.println("⚠️ Debe iniciar sesión como dueña para exportar los datos.");
                        break;
                    }
                    exportarInformacion(usuarios, productos, compras);
                }

                case 0 -> System.out.println("👋 Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }

        } while (opcion != 0);
    }

    // === MÉTODO DE COMPRA (CON DETALLE DE PRODUCTO) ===
    public static void realizarCompra(Scanner sc, Usuario usuarioActivo, List<Producto> productos,
                                      List<Compra> compras, Duena duena) {
        if (usuarioActivo == null || !(usuarioActivo instanceof Cliente)) {
            System.out.println("⚠️ Debe iniciar sesión como cliente para realizar una compra.");
            return;
        }

        Cliente cliente = (Cliente) usuarioActivo;

        System.out.println("\n=== PRODUCTOS DISPONIBLES ===");
        for (Producto p : productos) {
            System.out.println(p.getIdProducto() + " - " + p.getNombre() + " | $" + p.getPrecio());
        }

        System.out.print("Ingrese el ID del producto que desea comprar: ");
        int idProd = sc.nextInt();
        sc.nextLine();

        Producto seleccionado = null;
        for (Producto p : productos) {
            if (p.getIdProducto() == idProd) {
                seleccionado = p;
                break;
            }
        }

        if (seleccionado == null) {
            System.out.println("❌ Producto no encontrado.");
            return;
        }

        System.out.print("Cantidad: ");
        int cantidad = sc.nextInt();
        sc.nextLine();

        double total = cantidad * seleccionado.getPrecio();
        System.out.println("💰 Total a pagar: $" + total);
        System.out.println("Seleccione método de pago:");
        System.out.println("1. Efectivo");
        System.out.println("2. Tarjeta");
        System.out.println("3. Transferencia");
        System.out.print("Opción: ");
        int metodo = sc.nextInt();
        sc.nextLine();

        TipoPago tipoPago = switch (metodo) {
            case 1 -> TipoPago.EFECTIVO;
            case 2 -> TipoPago.TARJETA;
            case 3 -> TipoPago.TRANSFERENCIA;
            default -> TipoPago.EFECTIVO;
        };

        LineaCompra linea = new LineaCompra(seleccionado, cantidad);
        List<LineaCompra> lineas = new ArrayList<>();
        lineas.add(linea);

        Compra compra = new Compra(compras.size() + 1, cliente, lineas, tipoPago);
        compras.add(compra);
        duena.registrarCompra(compra);

        // ✅ Mostramos detalle del producto comprado
        System.out.println("\n✅ COMPRA REGISTRADA EXITOSAMENTE:");
        System.out.println("Cliente: " + cliente.getNombre());
        System.out.println("Producto: " + seleccionado.getNombre());
        System.out.println("Descripción: " + seleccionado.getDescripcion());
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Precio unitario: $" + seleccionado.getPrecio());
        System.out.println("Total: $" + total);
        System.out.println("Método de pago: " + tipoPago);
        System.out.println("Fecha: " + LocalDate.now());
    }

    // === FUNCIÓN PARA EXPORTAR INFORMACIÓN ===
    public static void exportarInformacion(List<Usuario> usuarios, List<Producto> productos, List<Compra> compras) {
        LocalDate fecha = LocalDate.now();
        String nombreArchivo = "Informacion_del_" + fecha.getDayOfMonth() + "-" + fecha.getMonthValue() + "-" + fecha.getYear() + ".txt";
        String rutaDescargas = System.getProperty("user.home") + "/Downloads/" + nombreArchivo;

        try (FileWriter writer = new FileWriter(rutaDescargas)) {
            writer.write("===== INFORME DE LA TIENDA =====\n");
            writer.write("Fecha: " + fecha + "\n\n");

            writer.write("=== USUARIOS REGISTRADOS ===\n");
            for (Usuario u : usuarios) {
                writer.write(u.toString() + "\n");
            }

            writer.write("\n=== PRODUCTOS ===\n");
            for (Producto p : productos) {
                writer.write(p.toString() + "\n");
            }

            writer.write("\n=== COMPRAS ===\n");
            for (Compra c : compras) {
                writer.write(c.toString() + "\n");
            }

            System.out.println("✅ Información exportada correctamente en: " + rutaDescargas);
        } catch (IOException e) {
            System.out.println("❌ Error al exportar el archivo: " + e.getMessage());
        }
    }
}
