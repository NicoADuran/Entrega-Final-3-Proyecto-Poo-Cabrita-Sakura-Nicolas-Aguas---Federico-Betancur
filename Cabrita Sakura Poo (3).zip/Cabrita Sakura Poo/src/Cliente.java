public class Cliente extends Usuario {

    private int idCliente;

    public Cliente(int idUsuario, String nombre, String apellido, String correo, String contrasena,
                   String direccion, String telefono, String estado, String rol, int idCliente) {
        super(idUsuario, nombre, apellido, correo, contrasena, direccion, telefono, estado, rol);
        this.idCliente = idCliente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    @Override
    public String toString() {
        return "Cliente #" + idCliente + " | " + getNombre() + " " + getApellido() +
                " | Correo: " + getCorreo() + " | Estado: " + getEstado();
    }
}
