import java.util.ArrayList;
import java.util.List;

/**
 * Clase que centraliza la lógica de registro y login de usuarios.
 * Administra tanto usuarios genéricos como clientes.
 */
public class RegistroUsuarios {

    private List<Usuario> usuarios;
    private int contadorIdUsuario = 1;
    private int contadorIdCliente = 1;

    public RegistroUsuarios() {
        this.usuarios = new ArrayList<>();
    }

    public RegistroUsuarios(List<Usuario> usuariosExistentes, int siguienteIdUsuario, int siguienteIdCliente) {
        this.usuarios = usuariosExistentes != null ? usuariosExistentes : new ArrayList<>();
        this.contadorIdUsuario = siguienteIdUsuario;
        this.contadorIdCliente = siguienteIdCliente;
    }

    // 🔹 Registra un cliente (extiende Usuario)
    public Cliente registrarCliente(String nombre, String apellido, String correo, String contrasena,
                                    String direccion, String telefono, String estado) {
        Cliente c = new Cliente(
                contadorIdUsuario++, nombre, apellido, correo, contrasena,
                direccion, telefono, estado, "Cliente", contadorIdCliente++
        );
        usuarios.add(c);
        System.out.println("Cliente registrado: " + nombre + " " + apellido);
        return c;
    }

    // 🔹 Registra un usuario genérico (por ejemplo, admin o dueña)
    public Usuario registrarUsuarioGenerico(String nombre, String apellido, String correo, String contrasena,
                                            String direccion, String telefono, String estado, String rol) {
        Usuario u = new Usuario(
                contadorIdUsuario++, nombre, apellido, correo, contrasena,
                direccion, telefono, estado, rol
        );
        usuarios.add(u);
        System.out.println("Usuario registrado: " + nombre + " " + apellido + " (Rol: " + rol + ")");
        return u;
    }

    // 🔹 Login: busca por correo y contraseña
    public Usuario login(String correo, String contrasena) {
        for (Usuario u : usuarios) {
            if (u.getCorreo().equalsIgnoreCase(correo) && u.getContrasena().equals(contrasena)) {
                System.out.println("Login exitoso: " + u.getNombre());
                return u;
            }
        }
        System.out.println("Login fallido para correo: " + correo);
        return null;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }
}
