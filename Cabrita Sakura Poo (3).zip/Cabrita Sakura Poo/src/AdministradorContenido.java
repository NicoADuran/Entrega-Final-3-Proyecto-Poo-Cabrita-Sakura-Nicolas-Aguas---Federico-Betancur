import java.util.ArrayList;
import java.util.List;

/**
 * Clase para gestionar contenido público: categorías y consejos de consumo.
 */
public class AdministradorContenido {
    // Crear una nueva categoría y retornarla (para que el main la agregue a su lista)
    public Categoria crearCategoria(int idCategoria, String nombre) {
        return new Categoria(idCategoria, nombre);
    }

    // Listar categorías (recibe la lista desde el main)
    public void listarCategorias(List<Categoria> categorias) {
        System.out.println("== Categorías ==");
        if (categorias == null || categorias.isEmpty()) {
            System.out.println("(ninguna)");
            return;
        }
        for (Categoria c : categorias) {
            System.out.printf("ID: %d | %s\n", c.getIdCategoria(), c.getNombre());
        }
    }

    // Generar un consejo simple para un producto
    public ConsejoConsumo generarConsejo(Producto producto, String mensaje) {
        return new ConsejoConsumo(producto, mensaje);
    }

    // Asociar una serie de consejos a un producto (devuelve lista con 1 item por sencillez)
    public List<ConsejoConsumo> generarConsejosParaProducto(Producto producto, String... mensajes) {
        List<ConsejoConsumo> lista = new ArrayList<>();
        for (String m : mensajes) {
            lista.add(new ConsejoConsumo(producto, m));
        }
        return lista;
    }
}
