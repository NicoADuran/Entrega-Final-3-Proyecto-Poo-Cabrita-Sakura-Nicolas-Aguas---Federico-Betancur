public enum TipoPago {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA,
    PAYPAL
}
