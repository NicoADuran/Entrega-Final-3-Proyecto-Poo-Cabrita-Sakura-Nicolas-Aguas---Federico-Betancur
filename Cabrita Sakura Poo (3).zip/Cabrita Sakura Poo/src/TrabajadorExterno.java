/**
 * Rol que representa a un trabajador externo (por ejemplo entrega/envíos).
 */
public class TrabajadorExterno {
    private int idTrabajador;
    private String nombre;

    public TrabajadorExterno(int idTrabajador, String nombre) {
        this.idTrabajador = idTrabajador;
        this.nombre = nombre;
    }

    public int getIdTrabajador() {
        return idTrabajador;
    }

    public String getNombre() {
        return nombre;
    }

    // Simula la entrega de una compra. Actualmente Compra no tiene estado,
    // así que aquí devolvemos true si hay lineas y mostramos mensaje.
    public boolean entregarCompra(Compra compra) {
        if (compra == null) return false;
        if (compra.getLineas().isEmpty()) {
            System.out.println("Compra vacía, nada que entregar.");
            return false;
        }
        System.out.printf("Trabajador %s entregó la compra id=%d al cliente %s\n", nombre, compra.getIdCompra(), compra.getCliente().getNombre());
        return true;
    }
}
