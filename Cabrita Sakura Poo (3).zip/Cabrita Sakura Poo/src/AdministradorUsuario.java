import java.util.List;

/**
 * Clase para gestionar usuarios: registrar, eliminar y listar.
 * No accede a campos privados directamente: usa getters/setters públicos.
 */
public class AdministradorUsuario {

    public AdministradorUsuario() {
    }

    /**
     * Registra un usuario (se añade a la lista pasada).
     */
    public void registrarUsuario(List<Usuario> usuarios, Usuario u) {
        if (usuarios == null) return;
        usuarios.add(u);
        System.out.println("Usuario registrado: " + u.getNombre() + " " + u.getApellido());
    }

    /**
     * Elimina un usuario por su idUsuario (usa getIdUsuario()).
     */
    public boolean eliminarUsuario(List<Usuario> usuarios, int idUsuario) {
        if (usuarios == null) return false;
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario u = usuarios.get(i);
            if (u != null && u.getIdUsuario() == idUsuario) {
                usuarios.remove(i);
                System.out.println("Usuario eliminado: id=" + idUsuario);
                return true;
            }
        }
        System.out.println("No se encontró usuario con id=" + idUsuario);
        return false;
    }

    /**
     * Lista los usuarios (usa getters públicos).
     */
    public void listarUsuarios(List<Usuario> usuarios) {
        if (usuarios == null || usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }

        System.out.println("== Usuarios ==");
        for (Usuario u : usuarios) {
            if (u == null) continue;
            System.out.printf("ID: %d | %s %s | Correo: %s | Rol: %s | Estado: %s\n",
                    u.getIdUsuario(),
                    safe(u.getNombre()),
                    safe(u.getApellido()),
                    safe(u.getCorreo()),
                    u.getRol() != null ? u.getRol() : "N/A",
                    u.getEstado() != null ? u.getEstado() : "N/A");
        }
    }

    // pequeño helper para evitar NPEs en Strings
    private String safe(String s) {
        return s == null ? "" : s;
    }
}
