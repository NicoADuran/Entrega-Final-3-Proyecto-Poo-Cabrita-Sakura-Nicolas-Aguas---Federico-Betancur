import java.util.ArrayList;
import java.util.List;

/**
 * Representa una fábrica/proveedor que mantiene un inventario de productos.
 */
public class Fabrica {
    private int idFabrica;
    private String nombre;
    private List<Producto> inventario;

    public Fabrica(int idFabrica, String nombre) {
        this.idFabrica = idFabrica;
        this.nombre = nombre;
        this.inventario = new ArrayList<>();
    }

    public int getIdFabrica() {
        return idFabrica;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Producto> getInventario() {
        return inventario;
    }

    public void agregarProductoAlInventario(Producto p) {
        inventario.add(p);
    }

    // Producir (crear) un producto: simplemente lo agrega al inventario
    public void producirProducto(Producto p) {
        inventario.add(p);
        System.out.println("Fábrica " + nombre + " produjo: " + p.getNombre());
    }

    // Buscar producto por id en la fabrica
    public Producto buscarPorId(int idProducto) {
        for (Producto p : inventario) {
            if (p.getIdProducto() == idProducto) return p;
        }
        return null;
    }

    // Enviar producto (remover del inventario y devolverlo para transferir)
    public Producto enviarProducto(int idProducto) {
        for (int i = 0; i < inventario.size(); i++) {
            if (inventario.get(i).getIdProducto() == idProducto) {
                return inventario.remove(i);
            }
        }
        return null;
    }

    public void listarInventario() {
        System.out.println("== Inventario fábrica: " + nombre + " ==");
        if (inventario.isEmpty()) {
            System.out.println(" (vacío)");
            return;
        }
        for (Producto p : inventario) {
            System.out.printf("ID: %d | %s | Precio: %.2f\n", p.getIdProducto(), p.getNombre(), p.getPrecio());
        }
    }
}
