import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa a la dueña del sistema.
 * Puede registrar clientes y ver sus compras.
 */
public class Duena extends Usuario {

    private List<Cliente> clientes;
    private List<Compra> compras;

    /**
     * Constructor corregido para coincidir con Usuario (9 parámetros).
     */
    public Duena(int idUsuario, String nombre, String apellido, String correo, String contrasena,
                 String direccion, String telefono, String estado, String rol) {
        super(idUsuario, nombre, apellido, correo, contrasena, direccion, telefono, estado, rol);
        this.clientes = new ArrayList<>();
        this.compras = new ArrayList<>();
    }

    /**
     * Registra un nuevo cliente
     */
    public void registrarCliente(Cliente cliente) {
        if (cliente != null) {
            clientes.add(cliente);
            System.out.println("Cliente registrado: " + cliente.getNombre() + " " + cliente.getApellido());
        }
    }

    /**
     * Registra una compra hecha por un cliente
     */
    public void registrarCompra(Compra compra) {
        if (compra != null) {
            compras.add(compra);
            System.out.println("Compra registrada para cliente: " +
                    (compra.getCliente() != null ? compra.getCliente().getNombre() : "Desconocido"));
        }
    }

    /**
     * Muestra todas las compras registradas
     */
    public void verCompras() {
        if (compras.isEmpty()) {
            System.out.println("No hay compras registradas.");
            return;
        }

        System.out.println("=== COMPRAS REGISTRADAS ===");
        for (Compra c : compras) {
            String clienteNombre = (c.getCliente() != null) ? c.getCliente().getNombre() : "Sin cliente";
            System.out.println("ID Compra: " + c.getIdCompra() +
                    " | Cliente: " + clienteNombre +
                    " | Total: " + c.calcularTotal());
        }
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public List<Compra> getCompras() {
        return compras;
    }
}
