import java.util.Date;
import java.util.List;

public class Compra {

    private int idCompra;
    private Date fecha;
    private Cliente cliente;
    private List<LineaCompra> lineas;
    private TipoPago tipoPago;

    public Compra(int idCompra, Cliente cliente, List<LineaCompra> lineas, TipoPago tipoPago) {
        this.idCompra = idCompra;
        this.fecha = new Date();
        this.cliente = cliente;
        this.lineas = lineas;
        this.tipoPago = tipoPago;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public Date getFecha() {
        return fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<LineaCompra> getLineas() {
        return lineas;
    }

    public TipoPago getTipoPago() {
        return tipoPago;
    }

    public double calcularTotal() {
        double total = 0;
        for (LineaCompra linea : lineas) {
            total += linea.getSubtotal();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Compra #" + idCompra + " | Cliente: " + cliente.getNombre() +
                " | Fecha: " + fecha +
                " | Pago: " + tipoPago +
                " | Total: $" + calcularTotal();
    }
}
