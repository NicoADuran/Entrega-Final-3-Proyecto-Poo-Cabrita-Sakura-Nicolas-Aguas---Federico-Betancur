public enum NivelCifrado {
    BAJO,
    MEDIO,
    ALTO
}
