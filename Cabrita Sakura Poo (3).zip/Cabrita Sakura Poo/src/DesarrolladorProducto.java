/**
 * Rol técnico que crea y modifica productos.
 */
public class DesarrolladorProducto {
    private int idDesarrollador;
    private String nombre;

    public DesarrolladorProducto(int idDesarrollador, String nombre) {
        this.idDesarrollador = idDesarrollador;
        this.nombre = nombre;
    }

    public Producto crearProducto(int idProducto, String nombreProducto, String descripcion, double precio, Categoria categoria, Fabricante fabricante) {
        Producto p = new Producto(idProducto, nombreProducto, descripcion, precio, categoria, fabricante);
        System.out.println("Producto creado por " + nombre + ": " + nombreProducto);
        return p;
    }

    public void actualizarPrecio(Producto p, double nuevoPrecio) {
        p.setPrecio(nuevoPrecio);
        System.out.printf("Precio actualizado para %s: %.2f\n", p.getNombre(), nuevoPrecio);
    }

    public void actualizarDescripcion(Producto p, String nuevaDescripcion) {
        p.setDescripcion(nuevaDescripcion);
        System.out.println("Descripción actualizada para " + p.getNombre());
    }
}
