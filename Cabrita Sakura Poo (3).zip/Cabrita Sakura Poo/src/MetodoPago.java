public class MetodoPago {
    private int idMetodo;
    private TipoPago tipo;
    private EstadoCuenta estado;

    public MetodoPago(int idMetodo, TipoPago tipo, EstadoCuenta estado) {
        this.idMetodo = idMetodo;
        this.tipo = tipo;
        this.estado = estado;
    }

    public int getIdMetodo() {
        return idMetodo;
    }

    public void setIdMetodo(int idMetodo) {
        this.idMetodo = idMetodo;
    }

    public TipoPago getTipo() {
        return tipo;
    }

    public void setTipo(TipoPago tipo) {
        this.tipo = tipo;
    }

    public EstadoCuenta getEstado() {
        return estado;
    }

    public void setEstado(EstadoCuenta estado) {
        this.estado = estado;
    }
}
