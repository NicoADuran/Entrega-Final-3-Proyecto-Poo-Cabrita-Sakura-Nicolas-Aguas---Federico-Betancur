package com.cabritasakura.Repository;

import com.cabritasakura.Model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    // 🔹 Buscar productos cuyo nombre contenga una palabra, sin importar mayúsculas/minúsculas
    List<Producto> findByNombreContainingIgnoreCase(String nombre);
}
