package com.cabritasakura.Repository;

import com.cabritasakura.Model.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface CompraRepository extends JpaRepository<Compra, Long> {

    @Query("SELECT c FROM Compra c WHERE c.cliente.idUsuario = :idCliente")
    List<Compra> findByClienteId(@Param("idCliente") Long idCliente);
}
