package com.cabritasakura.Repository;

import com.cabritasakura.Model.TrabajadorExterno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TrabajadorExternoRepository extends JpaRepository<TrabajadorExterno, Long> {
}
