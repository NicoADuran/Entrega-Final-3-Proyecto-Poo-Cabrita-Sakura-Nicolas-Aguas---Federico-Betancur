package com.cabritasakura.Repository;

import com.cabritasakura.Model.LineaCarrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LineaCarritoRepository extends JpaRepository<LineaCarrito, Long> {
}
