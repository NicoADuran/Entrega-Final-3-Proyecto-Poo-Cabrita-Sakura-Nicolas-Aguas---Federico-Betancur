package com.cabritasakura.Repository;

import com.cabritasakura.Model.DesarrolladorProducto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DesarrolladorProductoRepository extends JpaRepository<DesarrolladorProducto, Long> {
}
