package com.cabritasakura.Repository;

import com.cabritasakura.Model.ConsejoConsumo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ConsejoConsumoRepository extends JpaRepository<ConsejoConsumo, Long> {

    // 🔹 Busca todos los consejos asociados a un producto
    List<ConsejoConsumo> findByProductoIdProducto(Long idProducto);
}
