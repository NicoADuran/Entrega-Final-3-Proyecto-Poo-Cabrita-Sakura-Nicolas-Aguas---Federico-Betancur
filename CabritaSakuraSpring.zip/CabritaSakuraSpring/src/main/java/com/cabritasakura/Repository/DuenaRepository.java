package com.cabritasakura.Repository;

import com.cabritasakura.Model.Duena;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DuenaRepository extends JpaRepository<Duena, Long> {
}
