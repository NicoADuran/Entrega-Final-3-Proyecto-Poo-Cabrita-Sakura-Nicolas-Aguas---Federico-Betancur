package com.cabritasakura.Model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "clientes")
public class Cliente extends Usuario {

    @ManyToOne
    @JoinColumn(name = "id_duena")
    private Duena duena;

    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Compra> compras = new ArrayList<>();

    public Cliente() {
        super();
    }

    public Cliente(Long idUsuario, String nombre, String apellido, String correo, String contrasena,
                   String direccion, String telefono, String estado, String rol, Duena duena) {
        super(idUsuario, nombre, apellido, correo, contrasena, direccion, telefono, estado, rol);
        this.duena = duena;
    }

    public Duena getDuena() {
        return duena;
    }

    public void setDuena(Duena duena) {
        this.duena = duena;
    }

    public List<Compra> getCompras() {
        return compras;
    }

    public void setCompras(List<Compra> compras) {
        this.compras = compras;
    }
}
