package com.cabritasakura.Model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "fabricas")
public class Fabrica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_fabrica")
    private Long idFabrica;

    @Column(nullable = false, length = 100)
    private String nombre;

    // 🔹 Relación OneToMany con Producto
    @OneToMany(mappedBy = "fabrica", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Producto> inventario = new ArrayList<>();

    public Fabrica() {}

    public Fabrica(Long idFabrica, String nombre) {
        this.idFabrica = idFabrica;
        this.nombre = nombre;
    }

    public Long getIdFabrica() {
        return idFabrica;
    }

    public void setIdFabrica(Long idFabrica) {
        this.idFabrica = idFabrica;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Producto> getInventario() {
        return inventario;
    }

    public void setInventario(List<Producto> inventario) {
        this.inventario = inventario;
    }

    // Métodos de conveniencia
    public void agregarProducto(Producto producto) {
        inventario.add(producto);
        producto.setFabrica(this);
    }

    public void eliminarProducto(Producto producto) {
        inventario.remove(producto);
        producto.setFabrica(null);
    }

    @Override
    public String toString() {
        return "Fábrica: " + nombre + " (ID: " + idFabrica + ")";
    }
}
