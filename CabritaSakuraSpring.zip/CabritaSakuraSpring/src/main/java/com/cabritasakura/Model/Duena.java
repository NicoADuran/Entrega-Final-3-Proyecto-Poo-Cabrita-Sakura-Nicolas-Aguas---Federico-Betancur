package com.cabritasakura.Model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "duenas")
public class Duena extends Usuario {

    @OneToMany(mappedBy = "duena", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Cliente> clientes = new ArrayList<>();

    @OneToMany(mappedBy = "duena", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Compra> compras = new ArrayList<>();

    public Duena() {
        super();
    }

    public Duena(Long idUsuario, String nombre, String apellido, String correo, String contrasena,
                 String direccion, String telefono, String estado, String rol) {
        super(idUsuario, nombre, apellido, correo, contrasena, direccion, telefono, estado, rol);
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    public List<Compra> getCompras() {
        return compras;
    }

    public void setCompras(List<Compra> compras) {
        this.compras = compras;
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
        cliente.setDuena(this);
    }

    public void registrarCompra(Compra compra) {
        compras.add(compra);
        compra.setDuena(this);
    }

    @Override
    public String toString() {
        return "Dueña: " + getNombre() + " " + getApellido() + " (" + getCorreo() + ")";
    }
}
