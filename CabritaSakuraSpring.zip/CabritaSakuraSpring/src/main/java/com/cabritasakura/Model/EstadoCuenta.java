package com.cabritasakura.Model;

public enum EstadoCuenta {
    ACTIVO,
    INACTIVO,
    SUSPENDIDO
}
