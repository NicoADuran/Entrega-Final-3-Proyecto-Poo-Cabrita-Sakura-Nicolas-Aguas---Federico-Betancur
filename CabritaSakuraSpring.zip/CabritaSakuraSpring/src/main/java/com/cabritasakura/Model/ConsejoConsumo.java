package com.cabritasakura.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "consejos_consumo")
public class ConsejoConsumo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idConsejo; // ✅ Usar Long

    @Column(nullable = false, length = 255)
    private String descripcion;

    // 🔹 Relación ManyToOne con Producto
    @ManyToOne
    @JoinColumn(name = "id_producto", nullable = false)
    private Producto producto;

    public ConsejoConsumo() {}

    public ConsejoConsumo(String descripcion, Producto producto) {
        this.descripcion = descripcion;
        this.producto = producto;
    }

    public Long getIdConsejo() {
        return idConsejo;
    }

    public void setIdConsejo(Long idConsejo) {
        this.idConsejo = idConsejo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
}
