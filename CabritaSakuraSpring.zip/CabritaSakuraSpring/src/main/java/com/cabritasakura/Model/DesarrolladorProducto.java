package com.cabritasakura.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "desarrolladores_producto")
public class DesarrolladorProducto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDesarrollador;

    private String nombre;

    public DesarrolladorProducto() {
    }

    public DesarrolladorProducto(Long idDesarrollador, String nombre) {
        this.idDesarrollador = idDesarrollador;
        this.nombre = nombre;
    }

    public Long getIdDesarrollador() {
        return idDesarrollador;
    }

    public void setIdDesarrollador(Long idDesarrollador) {
        this.idDesarrollador = idDesarrollador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
