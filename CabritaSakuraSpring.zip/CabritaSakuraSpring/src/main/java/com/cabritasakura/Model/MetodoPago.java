package com.cabritasakura.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "metodos_pago")
public class MetodoPago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMetodo;

    @Enumerated(EnumType.STRING)
    private TipoPago tipo;

    @Enumerated(EnumType.STRING)
    private EstadoCuenta estado;

    public MetodoPago() {}

    public MetodoPago(TipoPago tipo, EstadoCuenta estado) {
        this.tipo = tipo;
        this.estado = estado;
    }

    public Long getIdMetodo() {
        return idMetodo;
    }

    public void setIdMetodo(Long idMetodo) {
        this.idMetodo = idMetodo;
    }

    public TipoPago getTipo() {
        return tipo;
    }

    public void setTipo(TipoPago tipo) {
        this.tipo = tipo;
    }

    public EstadoCuenta getEstado() {
        return estado;
    }

    public void setEstado(EstadoCuenta estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "MetodoPago{" +
                "idMetodo=" + idMetodo +
                ", tipo=" + tipo +
                ", estado=" + estado +
                '}';
    }
}
