package com.cabritasakura.Model;

public enum TipoPago {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA,
    PAYPAL
}
