package com.cabritasakura.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "trabajadores_externos")
public class TrabajadorExterno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTrabajador;

    private String nombre;

    // 🔹 Constructor vacío requerido por JPA
    public TrabajadorExterno() {}

    // 🔹 Constructor con parámetros
    public TrabajadorExterno(String nombre) {
        this.nombre = nombre;
    }

    // 🔹 Getters y Setters
    public Long getIdTrabajador() {
        return idTrabajador;
    }

    public void setIdTrabajador(Long idTrabajador) {
        this.idTrabajador = idTrabajador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "TrabajadorExterno{id=" + idTrabajador + ", nombre='" + nombre + "'}";
    }
}
