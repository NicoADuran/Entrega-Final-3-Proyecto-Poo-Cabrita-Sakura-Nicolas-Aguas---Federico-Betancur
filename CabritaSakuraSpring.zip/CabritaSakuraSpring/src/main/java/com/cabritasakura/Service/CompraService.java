package com.cabritasakura.Service;

import com.cabritasakura.Model.Compra;
import com.cabritasakura.Repository.CompraRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompraService {

    private final CompraRepository repository;

    public CompraService(CompraRepository repository) {
        this.repository = repository;
    }

    public List<Compra> listarTodas() {
        return repository.findAll();
    }

    public Optional<Compra> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public List<Compra> listarPorCliente(Long clienteId) {
        return repository.findByClienteId(clienteId);
    }

    public Compra guardar(Compra compra) {
        return repository.save(compra);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
