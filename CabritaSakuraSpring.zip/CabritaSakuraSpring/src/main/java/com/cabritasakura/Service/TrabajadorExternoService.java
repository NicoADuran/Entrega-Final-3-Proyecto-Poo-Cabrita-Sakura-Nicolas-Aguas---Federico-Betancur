package com.cabritasakura.Service;

import com.cabritasakura.Model.TrabajadorExterno;
import com.cabritasakura.Repository.TrabajadorExternoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrabajadorExternoService {

    @Autowired
    private TrabajadorExternoRepository repository;

    public List<TrabajadorExterno> listarTodos() {
        return repository.findAll();
    }

    public Optional<TrabajadorExterno> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public TrabajadorExterno guardar(TrabajadorExterno trabajador) {
        return repository.save(trabajador);
    }

    public TrabajadorExterno actualizar(Long id, TrabajadorExterno actualizado) {
        if (repository.existsById(id)) {
            actualizado.setIdTrabajador(id);
            return repository.save(actualizado);
        }
        return null;
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
