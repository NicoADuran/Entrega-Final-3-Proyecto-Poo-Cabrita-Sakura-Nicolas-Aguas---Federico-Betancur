package com.cabritasakura.Service;

import com.cabritasakura.Model.Carrito;
import com.cabritasakura.Model.Cliente;
import com.cabritasakura.Model.Producto;
import com.cabritasakura.Repository.CarritoRepository;
import org.springframework.stereotype.Service;

@Service
public class CarritoService {

    private final CarritoRepository carritoRepository;

    public CarritoService(CarritoRepository carritoRepository) {
        this.carritoRepository = carritoRepository;
    }

    public Carrito obtenerCarritoPorCliente(Cliente cliente) {
        return carritoRepository.findByCliente(cliente)
                .orElseGet(() -> {
                    Carrito nuevo = new Carrito();
                    nuevo.setCliente(cliente);
                    return carritoRepository.save(nuevo);
                });
    }

    public Carrito agregarProducto(Cliente cliente, Producto producto, int cantidad) {
        Carrito carrito = obtenerCarritoPorCliente(cliente);
        carrito.agregarProducto(producto, cantidad);
        return carritoRepository.save(carrito);
    }

    public Carrito eliminarProducto(Cliente cliente, Long idProducto) {
        Carrito carrito = obtenerCarritoPorCliente(cliente);
        carrito.eliminarProducto(idProducto);
        return carritoRepository.save(carrito);
    }

    public void vaciarCarrito(Cliente cliente) {
        Carrito carrito = obtenerCarritoPorCliente(cliente);
        carrito.vaciar();
        carritoRepository.save(carrito);
    }

    public double calcularTotal(Cliente cliente) {
        Carrito carrito = obtenerCarritoPorCliente(cliente);
        return carrito.calcularTotal();
    }
}
