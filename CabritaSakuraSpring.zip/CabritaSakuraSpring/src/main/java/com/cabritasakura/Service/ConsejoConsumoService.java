package com.cabritasakura.Service;

import com.cabritasakura.Model.ConsejoConsumo;
import com.cabritasakura.Repository.ConsejoConsumoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ConsejoConsumoService {

    private final ConsejoConsumoRepository repository;

    public ConsejoConsumoService(ConsejoConsumoRepository repository) {
        this.repository = repository;
    }

    public List<ConsejoConsumo> listarTodos() {
        return repository.findAll();
    }

    public List<ConsejoConsumo> listarPorProducto(Long productoId) {
        return repository.findByProductoIdProducto(productoId);
    }

    public Optional<ConsejoConsumo> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public ConsejoConsumo guardar(ConsejoConsumo consejo) {
        return repository.save(consejo);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
