package com.cabritasakura.Service;

import com.cabritasakura.Model.LineaCompra;
import com.cabritasakura.Repository.LineaCompraRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LineaCompraService {

    private final LineaCompraRepository lineaCompraRepository;

    public LineaCompraService(LineaCompraRepository lineaCompraRepository) {
        this.lineaCompraRepository = lineaCompraRepository;
    }

    public List<LineaCompra> listarLineasCompra() {
        return lineaCompraRepository.findAll();
    }

    public Optional<LineaCompra> obtenerLineaCompra(Long id) {
        return lineaCompraRepository.findById(id);
    }

    public LineaCompra guardarLineaCompra(LineaCompra lineaCompra) {
        return lineaCompraRepository.save(lineaCompra);
    }

    public void eliminarLineaCompra(Long id) {
        lineaCompraRepository.deleteById(id);
    }
}
