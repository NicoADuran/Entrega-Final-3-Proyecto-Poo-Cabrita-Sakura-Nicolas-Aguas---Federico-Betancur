package com.cabritasakura.Service;

import com.cabritasakura.Model.RegistroUsuarios;
import com.cabritasakura.Repository.RegistroUsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegistroUsuariosService {

    @Autowired
    private RegistroUsuariosRepository registroUsuariosRepository;

    public RegistroUsuarios guardar(RegistroUsuarios registro) {
        return registroUsuariosRepository.save(registro);
    }

    public List<RegistroUsuarios> listarRegistros() {
        return registroUsuariosRepository.findAll();
    }

    public RegistroUsuarios obtenerPorId(Long id) {
        return registroUsuariosRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Registro no encontrado con ID: " + id));
    }

    public void eliminarRegistro(Long id) {
        registroUsuariosRepository.deleteById(id);
    }
}
