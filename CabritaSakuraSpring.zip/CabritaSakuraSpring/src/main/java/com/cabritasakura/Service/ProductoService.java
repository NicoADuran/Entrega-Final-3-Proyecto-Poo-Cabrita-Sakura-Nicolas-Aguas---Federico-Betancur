package com.cabritasakura.Service;

import com.cabritasakura.Model.Producto;
import com.cabritasakura.Repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoService {

    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    // 🔹 Registrar o actualizar producto
    public Producto guardarProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    // 🔹 Obtener todos los productos
    public List<Producto> listarProductos() {
        return productoRepository.findAll();
    }

    // 🔹 Buscar producto por ID
    public Optional<Producto> buscarPorId(Long idProducto) {
        return productoRepository.findById(idProducto);
    }

    // 🔹 Nuevo: Obtener producto por ID (nombre más intuitivo)
    public Optional<Producto> obtenerProducto(Long idProducto) {
        return productoRepository.findById(idProducto);
    }

    // 🔹 Eliminar producto por ID
    public boolean eliminarProducto(Long idProducto) {
        if (productoRepository.existsById(idProducto)) {
            productoRepository.deleteById(idProducto);
            return true;
        }
        return false;
    }

    // 🔹 Buscar productos por nombre (opcional)
    public List<Producto> buscarPorNombre(String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    // 🔹 Actualizar stock (opcional)
    public void actualizarStock(Long idProducto, int nuevoStock) {
        Optional<Producto> productoOpt = productoRepository.findById(idProducto);
        if (productoOpt.isPresent()) {
            Producto producto = productoOpt.get();
            producto.setStock(nuevoStock);
            productoRepository.save(producto);
        } else {
            throw new IllegalArgumentException("Producto no encontrado con ID: " + idProducto);
        }
    }
}
