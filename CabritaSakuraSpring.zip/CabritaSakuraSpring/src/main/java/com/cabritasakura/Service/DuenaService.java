package com.cabritasakura.Service;

import com.cabritasakura.Model.Duena;
import com.cabritasakura.Repository.DuenaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DuenaService {

    private final DuenaRepository duenaRepository;

    public DuenaService(DuenaRepository duenaRepository) {
        this.duenaRepository = duenaRepository;
    }

    public List<Duena> listarDuenas() {
        return duenaRepository.findAll();
    }

    public Optional<Duena> obtenerDuena(Long id) {
        return duenaRepository.findById(id);
    }

    public Duena guardarDuena(Duena duena) {
        return duenaRepository.save(duena);
    }

    public void eliminarDuena(Long id) {
        duenaRepository.deleteById(id);
    }
}
