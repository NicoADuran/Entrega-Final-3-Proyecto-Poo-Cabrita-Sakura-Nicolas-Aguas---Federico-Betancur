package com.cabritasakura.Service;

import com.cabritasakura.Model.DesarrolladorProducto;
import com.cabritasakura.Repository.DesarrolladorProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DesarrolladorProductoService {

    private final DesarrolladorProductoRepository repository;

    public DesarrolladorProductoService(DesarrolladorProductoRepository repository) {
        this.repository = repository;
    }

    public List<DesarrolladorProducto> listarTodos() {
        return repository.findAll();
    }

    public Optional<DesarrolladorProducto> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public DesarrolladorProducto guardar(DesarrolladorProducto d) {
        return repository.save(d);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
