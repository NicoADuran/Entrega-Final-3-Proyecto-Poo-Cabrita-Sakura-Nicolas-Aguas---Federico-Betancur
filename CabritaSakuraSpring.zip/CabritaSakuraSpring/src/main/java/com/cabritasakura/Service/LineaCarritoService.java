package com.cabritasakura.Service;

import com.cabritasakura.Model.LineaCarrito;
import com.cabritasakura.Repository.LineaCarritoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LineaCarritoService {

    private final LineaCarritoRepository lineaCarritoRepository;

    public LineaCarritoService(LineaCarritoRepository lineaCarritoRepository) {
        this.lineaCarritoRepository = lineaCarritoRepository;
    }

    public List<LineaCarrito> listarLineas() {
        return lineaCarritoRepository.findAll();
    }

    public Optional<LineaCarrito> obtenerLinea(Long id) {
        return lineaCarritoRepository.findById(id);
    }

    public LineaCarrito guardarLinea(LineaCarrito linea) {
        return lineaCarritoRepository.save(linea);
    }

    public void eliminarLinea(Long id) {
        lineaCarritoRepository.deleteById(id);
    }
}
