package com.cabritasakura.Service;

import com.cabritasakura.Model.Fabrica;
import com.cabritasakura.Repository.FabricaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FabricaService {

    private final FabricaRepository fabricaRepository;

    public FabricaService(FabricaRepository fabricaRepository) {
        this.fabricaRepository = fabricaRepository;
    }

    public List<Fabrica> listarFabricas() {
        return fabricaRepository.findAll();
    }

    public Optional<Fabrica> obtenerFabrica(Long id) {
        return fabricaRepository.findById(id);
    }

    public Fabrica guardarFabrica(Fabrica fabrica) {
        return fabricaRepository.save(fabrica);
    }

    public void eliminarFabrica(Long id) {
        fabricaRepository.deleteById(id);
    }
}
