package com.cabritasakura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabritaSakuraApplication {

    public static void main(String[] args) {
        SpringApplication.run(CabritaSakuraApplication.class, args);
        System.out.println("🚀 Servidor Spring Boot iniciado correctamente en http://localhost:8080");
    }
}
