package com.cabritasakura.Controller;

import com.cabritasakura.Model.Usuario;
import com.cabritasakura.Service.AdministradorUsuarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuarios")
@CrossOrigin(origins = "*")
public class AdministradorUsuarioController {

    private final AdministradorUsuarioService usuarioService;

    public AdministradorUsuarioController(AdministradorUsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // 🔹 Registrar usuario
    @PostMapping("/registrar")
    public Usuario registrar(@RequestBody Usuario usuario) {
        return usuarioService.registrarUsuario(usuario);
    }

    // 🔹 Eliminar usuario
    @DeleteMapping("/eliminar/{idUsuario}")
    public String eliminar(@PathVariable Long idUsuario) {
        boolean eliminado = usuarioService.eliminarUsuario(idUsuario);
        return eliminado ? "Usuario eliminado correctamente" : "Usuario no encontrado";
    }

    // 🔹 Listar todos los usuarios
    @GetMapping("/listar")
    public List<Usuario> listar() {
        return usuarioService.listarUsuarios();
    }

    // 🔹 Buscar usuario por ID
    @GetMapping("/{idUsuario}")
    public Optional<Usuario> obtenerPorId(@PathVariable Long idUsuario) {
        return usuarioService.buscarPorId(idUsuario);
    }
}
