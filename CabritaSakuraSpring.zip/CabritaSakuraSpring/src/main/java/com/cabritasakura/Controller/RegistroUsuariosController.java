package com.cabritasakura.Controller;

import com.cabritasakura.Model.RegistroUsuarios;
import com.cabritasakura.Model.Usuario;
import com.cabritasakura.Service.RegistroUsuariosService;
import com.cabritasakura.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/registros")
@CrossOrigin(origins = "*")
public class RegistroUsuariosController {

    @Autowired
    private RegistroUsuariosService registroUsuariosService;

    @Autowired
    private UsuarioService usuarioService;

    // 🔹 Crear un nuevo registro para un usuario existente
    @PostMapping
    public RegistroUsuarios crearRegistro(
            @RequestParam Long idUsuario,
            @RequestParam String accion
    ) {
        Usuario usuario = usuarioService.buscarPorId(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + idUsuario));

        RegistroUsuarios registro = new RegistroUsuarios(
                usuario,
                accion,
                LocalDateTime.now()
        );

        return registroUsuariosService.guardar(registro);
    }

    // 🔹 Listar todos los registros
    @GetMapping
    public List<RegistroUsuarios> listarRegistros() {
        return registroUsuariosService.listarRegistros();
    }

    // 🔹 Obtener registro por ID
    @GetMapping("/{id}")
    public RegistroUsuarios obtenerRegistro(@PathVariable Long id) {
        return registroUsuariosService.obtenerPorId(id);
    }

    // 🔹 Eliminar registro
    @DeleteMapping("/{id}")
    public void eliminarRegistro(@PathVariable Long id) {
        registroUsuariosService.eliminarRegistro(id);
    }
}
