package com.cabritasakura.Controller;

import com.cabritasakura.Model.MetodoPago;
import com.cabritasakura.Service.MetodoPagoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/metodos-pago")
public class MetodoPagoController {

    private final MetodoPagoService metodoPagoService;

    public MetodoPagoController(MetodoPagoService metodoPagoService) {
        this.metodoPagoService = metodoPagoService;
    }

    @GetMapping
    public List<MetodoPago> listar() {
        return metodoPagoService.listarMetodosPago();
    }

    @GetMapping("/{id}")
    public Optional<MetodoPago> obtener(@PathVariable Long id) {
        return metodoPagoService.obtenerMetodoPago(id);
    }

    @PostMapping
    public MetodoPago crear(@RequestBody MetodoPago metodoPago) {
        return metodoPagoService.guardarMetodoPago(metodoPago);
    }

    @PutMapping("/{id}")
    public MetodoPago actualizar(@PathVariable Long id, @RequestBody MetodoPago metodoPago) {
        metodoPago.setIdMetodo(id);
        return metodoPagoService.guardarMetodoPago(metodoPago);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        metodoPagoService.eliminarMetodoPago(id);
    }
}
