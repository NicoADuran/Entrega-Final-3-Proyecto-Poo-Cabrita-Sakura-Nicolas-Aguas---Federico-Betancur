package com.cabritasakura.Controller;

import com.cabritasakura.Model.LineaCompra;
import com.cabritasakura.Service.LineaCompraService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/lineas-compra")
public class LineaCompraController {

    private final LineaCompraService lineaCompraService;

    public LineaCompraController(LineaCompraService lineaCompraService) {
        this.lineaCompraService = lineaCompraService;
    }

    @GetMapping
    public List<LineaCompra> listar() {
        return lineaCompraService.listarLineasCompra();
    }

    @GetMapping("/{id}")
    public Optional<LineaCompra> obtener(@PathVariable Long id) {
        return lineaCompraService.obtenerLineaCompra(id);
    }

    @PostMapping
    public LineaCompra crear(@RequestBody LineaCompra lineaCompra) {
        return lineaCompraService.guardarLineaCompra(lineaCompra);
    }

    @PutMapping("/{id}")
    public LineaCompra actualizar(@PathVariable Long id, @RequestBody LineaCompra lineaCompra) {
        lineaCompra.setIdLinea(id);
        return lineaCompraService.guardarLineaCompra(lineaCompra);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        lineaCompraService.eliminarLineaCompra(id);
    }
}
