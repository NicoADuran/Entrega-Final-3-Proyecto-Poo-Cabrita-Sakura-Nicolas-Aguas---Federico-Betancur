package com.cabritasakura.Controller;

import com.cabritasakura.Model.TrabajadorExterno;
import com.cabritasakura.Service.TrabajadorExternoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/trabajadores")
@CrossOrigin(origins = "*")
public class TrabajadorExternoController {

    @Autowired
    private TrabajadorExternoService service;

    @GetMapping
    public List<TrabajadorExterno> listar() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public Optional<TrabajadorExterno> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public TrabajadorExterno crear(@RequestBody TrabajadorExterno trabajador) {
        return service.guardar(trabajador);
    }

    @PutMapping("/{id}")
    public TrabajadorExterno actualizar(@PathVariable Long id, @RequestBody TrabajadorExterno trabajador) {
        return service.actualizar(id, trabajador);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
