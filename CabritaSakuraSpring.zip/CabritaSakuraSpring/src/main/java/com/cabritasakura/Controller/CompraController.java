package com.cabritasakura.Controller;

import com.cabritasakura.Model.Compra;
import com.cabritasakura.Service.CompraService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compras")
public class CompraController {

    private final CompraService service;

    public CompraController(CompraService service) {
        this.service = service;
    }

    @GetMapping
    public List<Compra> listarTodas() {
        return service.listarTodas();
    }

    @GetMapping("/{id}")
    public Compra buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id).orElse(null);
    }

    @GetMapping("/cliente/{clienteId}")
    public List<Compra> listarPorCliente(@PathVariable Long clienteId) {
        return service.listarPorCliente(clienteId);
    }

    @PostMapping
    public Compra crear(@RequestBody Compra compra) {
        return service.guardar(compra);
    }

    @PutMapping("/{id}")
    public Compra actualizar(@PathVariable Long id, @RequestBody Compra compra) {
        compra.setIdCompra(id);
        return service.guardar(compra);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
