package com.cabritasakura.Controller;

import com.cabritasakura.Model.Fabricante;
import com.cabritasakura.Service.FabricanteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/fabricantes")
public class FabricanteController {

    private final FabricanteService fabricanteService;

    public FabricanteController(FabricanteService fabricanteService) {
        this.fabricanteService = fabricanteService;
    }

    @GetMapping
    public List<Fabricante> listar() {
        return fabricanteService.listarFabricantes();
    }

    @GetMapping("/{id}")
    public Optional<Fabricante> obtener(@PathVariable Long id) {
        return fabricanteService.obtenerFabricante(id);
    }

    @PostMapping
    public Fabricante crear(@RequestBody Fabricante fabricante) {
        return fabricanteService.guardarFabricante(fabricante);
    }

    @PutMapping("/{id}")
    public Fabricante actualizar(@PathVariable Long id, @RequestBody Fabricante fabricante) {
        fabricante.setIdFabricante(id);
        return fabricanteService.guardarFabricante(fabricante);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        fabricanteService.eliminarFabricante(id);
    }
}
