package com.cabritasakura.Controller;

import com.cabritasakura.Model.Carrito;
import com.cabritasakura.Model.Cliente;
import com.cabritasakura.Model.Producto;
import com.cabritasakura.Service.CarritoService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/carritos")
@CrossOrigin(origins = "*")
public class CarritoController {

    private final CarritoService carritoService;

    public CarritoController(CarritoService carritoService) {
        this.carritoService = carritoService;
    }

    // 🔹 Obtener carrito por cliente
    @GetMapping("/{idCliente}")
    public Carrito obtenerCarrito(@PathVariable Long idCliente) {
        Cliente cliente = new Cliente();
        cliente.setIdUsuario(idCliente);
        return carritoService.obtenerCarritoPorCliente(cliente);
    }

    // 🔹 Agregar producto al carrito
    @PostMapping("/{idCliente}/agregar")
    public Carrito agregarProducto(
            @PathVariable Long idCliente,
            @RequestParam Long idProducto,
            @RequestParam int cantidad) {

        Cliente cliente = new Cliente();
        cliente.setIdUsuario(idCliente);

        Producto producto = new Producto();
        producto.setIdProducto(idProducto);

        return carritoService.agregarProducto(cliente, producto, cantidad);
    }

    // 🔹 Eliminar producto del carrito
    @DeleteMapping("/{idCliente}/eliminar/{idProducto}")
    public Carrito eliminarProducto(@PathVariable Long idCliente, @PathVariable Long idProducto) {
        Cliente cliente = new Cliente();
        cliente.setIdUsuario(idCliente);
        return carritoService.eliminarProducto(cliente, idProducto);
    }

    // 🔹 Vaciar carrito
    @DeleteMapping("/{idCliente}/vaciar")
    public void vaciarCarrito(@PathVariable Long idCliente) {
        Cliente cliente = new Cliente();
        cliente.setIdUsuario(idCliente);
        carritoService.vaciarCarrito(cliente);
    }

    // 🔹 Calcular total
    @GetMapping("/{idCliente}/total")
    public double calcularTotal(@PathVariable Long idCliente) {
        Cliente cliente = new Cliente();
        cliente.setIdUsuario(idCliente);
        return carritoService.calcularTotal(cliente);
    }
}
