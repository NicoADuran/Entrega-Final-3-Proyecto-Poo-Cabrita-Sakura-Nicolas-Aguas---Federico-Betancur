package com.cabritasakura.Controller;

import com.cabritasakura.Model.Fabrica;
import com.cabritasakura.Service.FabricaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/fabricas")
public class FabricaController {

    private final FabricaService fabricaService;

    public FabricaController(FabricaService fabricaService) {
        this.fabricaService = fabricaService;
    }

    @GetMapping
    public List<Fabrica> listar() {
        return fabricaService.listarFabricas();
    }

    @GetMapping("/{id}")
    public Optional<Fabrica> obtener(@PathVariable Long id) {
        return fabricaService.obtenerFabrica(id);
    }

    @PostMapping
    public Fabrica crear(@RequestBody Fabrica fabrica) {
        return fabricaService.guardarFabrica(fabrica);
    }

    @PutMapping("/{id}")
    public Fabrica actualizar(@PathVariable Long id, @RequestBody Fabrica fabrica) {
        fabrica.setIdFabrica(id);
        return fabricaService.guardarFabrica(fabrica);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        fabricaService.eliminarFabrica(id);
    }
}
