package com.cabritasakura.Controller;

import com.cabritasakura.Model.DesarrolladorProducto;
import com.cabritasakura.Service.DesarrolladorProductoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/desarrolladores")
public class DesarrolladorProductoController {

    private final DesarrolladorProductoService service;

    public DesarrolladorProductoController(DesarrolladorProductoService service) {
        this.service = service;
    }

    @GetMapping
    public List<DesarrolladorProducto> listar() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public DesarrolladorProducto buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id).orElse(null);
    }

    @PostMapping
    public DesarrolladorProducto crear(@RequestBody DesarrolladorProducto d) {
        return service.guardar(d);
    }

    @PutMapping("/{id}")
    public DesarrolladorProducto actualizar(@PathVariable Long id, @RequestBody DesarrolladorProducto d) {
        d.setIdDesarrollador(id);
        return service.guardar(d);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
