package com.cabritasakura.Controller;

import com.cabritasakura.Model.ConsejoConsumo;
import com.cabritasakura.Service.ConsejoConsumoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/consejos")
@CrossOrigin(origins = "*")
public class ConsejoConsumoController {

    @Autowired
    private ConsejoConsumoService service;

    // 🔹 Listar todos los consejos
    @GetMapping
    public ResponseEntity<List<ConsejoConsumo>> listarTodos() {
        return ResponseEntity.ok(service.listarTodos());
    }

    // 🔹 Listar consejos por producto
    @GetMapping("/producto/{productoId}")
    public ResponseEntity<List<ConsejoConsumo>> listarPorProducto(@PathVariable Long productoId) {
        List<ConsejoConsumo> consejos = service.listarPorProducto(productoId);
        return ResponseEntity.ok(consejos);
    }

    // 🔹 Buscar por ID
    @GetMapping("/{id}")
    public ResponseEntity<ConsejoConsumo> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 🔹 Crear nuevo consejo
    @PostMapping
    public ResponseEntity<ConsejoConsumo> crearConsejo(@RequestBody ConsejoConsumo consejo) {
        ConsejoConsumo nuevo = service.guardar(consejo);
        return ResponseEntity.ok(nuevo);
    }

    // 🔹 Actualizar un consejo
    @PutMapping("/{id}")
    public ResponseEntity<ConsejoConsumo> actualizarConsejo(
            @PathVariable Long id,
            @RequestBody ConsejoConsumo consejoActualizado) {

        return service.buscarPorId(id)
                .map(consejo -> {
                    consejo.setDescripcion(consejoActualizado.getDescripcion());
                    consejo.setProducto(consejoActualizado.getProducto());
                    ConsejoConsumo actualizado = service.guardar(consejo);
                    return ResponseEntity.ok(actualizado);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // 🔹 Eliminar un consejo
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarConsejo(@PathVariable Long id) {
        if (service.buscarPorId(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
