package com.cabritasakura.Controller;

import com.cabritasakura.Model.Duena;
import com.cabritasakura.Service.DuenaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/duenas")
public class DuenaController {

    private final DuenaService duenaService;

    public DuenaController(DuenaService duenaService) {
        this.duenaService = duenaService;
    }

    @GetMapping
    public List<Duena> listar() {
        return duenaService.listarDuenas();
    }

    @GetMapping("/{id}")
    public Optional<Duena> obtener(@PathVariable Long id) {
        return duenaService.obtenerDuena(id);
    }

    @PostMapping
    public Duena crear(@RequestBody Duena duena) {
        return duenaService.guardarDuena(duena);
    }

    @PutMapping("/{id}")
    public Duena actualizar(@PathVariable Long id, @RequestBody Duena duena) {
        duena.setIdUsuario(Long.valueOf(id));
        return duenaService.guardarDuena(duena);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        duenaService.eliminarDuena(id);
    }
}
