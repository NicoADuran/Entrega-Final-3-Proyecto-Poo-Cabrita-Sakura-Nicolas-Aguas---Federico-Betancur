package com.cabritasakura.Controller;

import com.cabritasakura.Model.LineaCarrito;
import com.cabritasakura.Service.LineaCarritoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/lineas-carrito")
public class LineaCarritoController {

    private final LineaCarritoService lineaCarritoService;

    public LineaCarritoController(LineaCarritoService lineaCarritoService) {
        this.lineaCarritoService = lineaCarritoService;
    }

    @GetMapping
    public List<LineaCarrito> listar() {
        return lineaCarritoService.listarLineas();
    }

    @GetMapping("/{id}")
    public Optional<LineaCarrito> obtener(@PathVariable Long id) {
        return lineaCarritoService.obtenerLinea(id);
    }

    @PostMapping
    public LineaCarrito crear(@RequestBody LineaCarrito linea) {
        return lineaCarritoService.guardarLinea(linea);
    }

    @PutMapping("/{id}")
    public LineaCarrito actualizar(@PathVariable Long id, @RequestBody LineaCarrito linea) {
        linea.setIdLinea(id);
        return lineaCarritoService.guardarLinea(linea);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        lineaCarritoService.eliminarLinea(id);
    }
}
